// Created by Vijaya Yeruva on 11/20/2020
// Reference: https://developer.android.com/guide/topics/ui/notifiers/notifications

package com.example.notification;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.provider.CalendarContract;
import android.view.View;
import android.widget.CalendarView;
import android.widget.TextView;
import android.widget.Toast;
import android.os.Bundle;
import android.view.View;


import java.text.DateFormat;
import java.util.Calendar;
import java.util.Date;

public class MainActivity extends AppCompatActivity {
    TextView dateView;
    CalendarView calendarView;
    //Button btnCreateEvent;
    int YEAR, MONTH, DAY;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        dateView = findViewById(R.id.dateView);
        calendarView = findViewById(R.id.calendarView);
        //btnCreateEvent = findViewById(R.id.btnCreateEvent);

        // Set calendar to current date
        calendarView.setDate(Calendar.getInstance().getTime());

        // sets initial string for dateView
        final DateFormat df = DateFormat.getDateInstance(DateFormat.LONG);
        dateView.setText(df.format(calendarView.getDate()));

        // Change date string in dateView when user selects a new date
        private DatePickerDialog.OnDateSetListener myDateListener = new DatePickerDialog.OnDateSetListener() {
    @Override
    public void onDateSet(DatePicker arg0, int year, int month, int day) {
        dateView.setText(new StringBuilder()
            // Month is 0 based so add 1
            .append(day).append("-") //day
            .append(month+1).append("-")//month
            .append(year).append(" "));//year
        from_date=dateView.getText().toString();
        startActivity(new Intent(datefrom.this, dateto.class));
    }
});

        public void open(View view){
        //function used when + button is clicked
            Calendar cal = Calendar.getInstance();

            //will set the year, month, day variables
            calendarView.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
                @Override
                public void onSelectedDayChange(@NonNull CalendarView view, int year, int month, int dayOfMonth) {
                    // Create new date object from parameters for long date format
                    Date date = new GregorianCalendar(year, month, dayOfMonth).getTime();
                    YEAR = year; MONTH = month; DAY = dayOfMonth;

                    //dateView.setText(df.format(date));
                }
            });
            //used to open google calenar app
            @Override
       public void onClick(View arg0) {
       if(arg0.getId() == R.id.btnAddToCal)
   { 

    long startTime = 0, endTime=0;

    String startDate = blankevent.EventDate;
    try {
        Date date = new SimpleDateFormat("yyyy-MM-dd").parse(startDate);
        startTime=date.getTime();
    }
    catch(Exception e){ }   


    Calendar cal = Calendar.getInstance();              
    Intent calintent = new Intent(Intent.ACTION_EDIT);
    calintent.setType("vnd.android.cursor.item/event");
    calintent.putExtra("eventLocation", blankevent.EventLocation);
    calintent.putExtra("title", blankevent.EventName);
    calintent.putExtra("description", blankevent.EventDetails);

    calintent.putExtra("beginTime",startTime);
    calintent.putExtra("dtstart", blankevent.EventTime);

  startActivity(calintent);
   return;
 }